from django import forms
from .models import Post


class ProfileForm(forms.ModelForm):
    
    class Meta:
        model = Post
        fields = "__all__"
        labels ={
            'Title':'Title of place ',
            'imagename':'place image name',  
            'date':'type date'      
        }
        
   