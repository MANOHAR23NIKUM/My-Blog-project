from django.shortcuts import render,redirect
from .models import Post,Author
from django.http import Http404
from .forms import ProfileForm
# Create your views here.


def get_date(post):
    return post.date

def Home(request):
    post = Post.objects.all()
    sorted_posts = sorted(post,key=get_date)
    post = sorted_posts[-3:]
    return render(request, 'blog/home.html',{
        'posts':post
    })


def AllPost(request):
    all_posts= Post.objects.all()
    return render(request,'blog/Allpost.html',{
        'all_post': all_posts
    })
   
def PostDetails(request,slug):
    try:
        post = Post.objects.get(slug=slug)
    except:
        raise Http404()
    return render(request,'blog/details.html',{
        'Title':post.Title,
        'imagename':post.imagename,
        'content':post.content,
        'date':post.date,
        'author':post.author,
        'tags':post.tags,
        'image':post.image
          
    })
    


def form_upload(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('success')

    form = ProfileForm()
    return render (request,'blog/form.html',{
        'form':form
    })
    
    

def thankyou(request):
    return render(request,'blog/thankyou.html')

