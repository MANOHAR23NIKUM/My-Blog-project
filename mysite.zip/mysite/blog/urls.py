from django.urls import path
from . import views

urlpatterns = [
    path('home/', views.Home,name='home'),
    path('allpost/', views.AllPost, name='all_post'),
    path('Post_details/<slug:slug>/', views.PostDetails,name='post_details'),
    path("form_upload",views.form_upload,name='form-upload'),
    path("thank-you",views.thankyou,name='success')


]